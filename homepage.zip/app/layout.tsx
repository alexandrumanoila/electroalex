import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Link from "next/link"
import { Phone, Mail, Menu } from "lucide-react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ElectroAlex - Instalații Electrice Profesionale",
  description: "ElectroAlex Arbore SRL - Peste 30 de ani de experiență în instalații electrice. Autorizați ANRE.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ro">
      <body className={inter.className}>
        <div className="bg-blue-600 text-white py-2 px-4">
          <div className="container mx-auto flex justify-between items-center">
            <div className="flex items-center">
              <Phone className="h-4 w-4 mr-2" />
              <span className="text-sm">0770 670 185 / 0744 506 331</span>
            </div>
            <div className="flex items-center">
              <Mail className="h-4 w-4 mr-2" />
              <span className="text-sm">electroalex@yahoo.com</span>
            </div>
          </div>
        </div>

        <header className="bg-white py-4 px-4 shadow-sm sticky top-0 z-50">
          <div className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-blue-600 font-bold text-2xl">
              ELECTROALEX
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-gray-800 hover:text-blue-600">
                Acasă
              </Link>
              <Link href="/despre-noi" className="text-gray-800 hover:text-blue-600">
                Despre noi
              </Link>
              <Link href="/servicii" className="text-gray-800 hover:text-blue-600">
                Servicii
              </Link>
              <Link href="/galerie" className="text-gray-800 hover:text-blue-600">
                Galerie
              </Link>
              <Link href="/contact" className="text-gray-800 hover:text-blue-600">
                Contact
              </Link>
            </nav>
            <div className="md:hidden">
              <button className="text-blue-900">
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </header>

        <main>{children}</main>

        <footer className="bg-blue-800 text-white py-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">ELECTROALEX</h3>
                <p className="text-blue-200">Instalații electrice profesionale</p>
                <p className="text-blue-200 mt-2">Autorizați ANRE</p>
                <p className="text-blue-200 mt-2">Peste 30 de ani de experiență</p>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Contact</h4>
                <p className="text-blue-200 mb-1">Telefon: 0770 670 185 / 0744 506 331</p>
                <p className="text-blue-200 mb-1">Email: electroalex@yahoo.com</p>
                <p className="text-blue-200">Email: manoilaalex1@gmail.com</p>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Adresă</h4>
                <p className="text-blue-200 mb-3">Electroalex, DN2K, Arbore 727015, Județul Suceava</p>
                <div className="flex space-x-3">
                  <a
                    href="https://www.google.com/maps/search/?api=1&query=Electroalex+Arbore+Suceava"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                  >
                    Google Maps
                  </a>
                  <a
                    href="https://www.waze.com/ul?ll=47.7252%2C25.9244&navigate=yes"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                  >
                    Waze
                  </a>
                </div>
              </div>
            </div>
            <div className="border-t border-blue-700 mt-8 pt-4 text-center text-blue-300 text-sm">
              <p>© {new Date().getFullYear()} ElectroAlex Arbore SRL. Toate drepturile rezervate.</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}


import './globals.css'