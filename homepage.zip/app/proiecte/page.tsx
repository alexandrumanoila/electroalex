import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function ProiectePage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Top contact bar and Navigation will be added in a layout component */}

      <main className="flex-grow bg-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-8">
            <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Înapoi la pagina principală
            </Link>
          </div>

          <h1 className="text-3xl font-bold text-blue-800 mb-8">Proiectele noastre</h1>

          <div className="space-y-12">
            {[1, 2, 3].map((project) => (
              <div key={project} className="border border-gray-200 rounded-lg overflow-hidden shadow-md">
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="p-6">
                    <h2 className="text-2xl font-semibold text-blue-700 mb-4">Proiect {project}</h2>
                    <p className="text-gray-600 mb-4">
                      Instalație electrică completă pentru o{" "}
                      {project === 1 ? "casă rezidențială" : project === 2 ? "clădire de birouri" : "hală industrială"}
                      din {project === 1 ? "Arbore" : project === 2 ? "Suceava" : "Rădăuți"}.
                    </p>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="font-medium">Client:</span>
                        <span>{project === 1 ? "Rezidențial" : project === 2 ? "Comercial" : "Industrial"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Locație:</span>
                        <span>{project === 1 ? "Arbore" : project === 2 ? "Suceava" : "Rădăuți"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Anul:</span>
                        <span>{2020 + project}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Durata:</span>
                        <span>{project * 2} săptămâni</span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 p-2">
                    <Image
                      src={`/placeholder.svg?height=200&width=300&text=Proiect ${project}.1`}
                      alt={`Proiect ${project} imagine 1`}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover rounded"
                    />
                    <Image
                      src={`/placeholder.svg?height=200&width=300&text=Proiect ${project}.2`}
                      alt={`Proiect ${project} imagine 2`}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover rounded"
                    />
                    <Image
                      src={`/placeholder.svg?height=200&width=300&text=Proiect ${project}.3`}
                      alt={`Proiect ${project} imagine 3`}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover rounded"
                    />
                    <Image
                      src={`/placeholder.svg?height=200&width=300&text=Proiect ${project}.4`}
                      alt={`Proiect ${project} imagine 4`}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover rounded"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
