import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function GaleriePage() {
  const projects = [
    {
      id: 1,
      title: "Instalare contor electric",
      description: "Instalare contor electric pentru șantier de construcții",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_e7e7470b.jpg-xa5yij2MzZRJPL1haNO5jRXrCRTf5r.jpeg",
    },
    {
      id: 2,
      title: "Lucrări la rețeaua electrică",
      description: "Lucrări de mentenanță la rețeaua electrică cu autoutilitară cu nacelă",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_170ae220.jpg-6rRLzrks9yHfzg2ec1rKaRHuvd8u81.jpeg",
    },
    {
      id: 3,
      title: "Tablou electric rezidențial",
      description: "Instalare tablou electric pentru locuință",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_22251971.jpg-KW52zR9BoX6FsCT306SFhwyHGRvXV7.jpeg",
    },
    {
      id: 4,
      title: "Contor Delgaz Grid",
      description: "Montaj contor electric Delgaz Grid pentru locuință",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.13_b7a139da.jpg-mQoicb6ew32kNXsA85dwDANuBJZKGS.jpeg",
    },
    {
      id: 5,
      title: "Iluminat public",
      description: "Instalare stâlpi de iluminat în parc",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_719a9687.jpg-evAOsgJ8Mu84OTHOCyZKaLbajCM7oV.jpeg",
    },
    {
      id: 6,
      title: "Contor electric pe stâlp",
      description: "Montaj contor DelGaz Grid",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_da824b46.jpg-HikYN3hiXhDV16DoUz6hlCeV5GUErE.jpeg",
    },
    {
      id: 7,
      title: "Corpuri de iluminat LED",
      description: "Lămpi moderne pentru iluminat stradal",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_ed697200.jpg-hZp6A8rP8a1E2DLnHKWY0yOFqF28Vq.jpeg",
    },
    {
      id: 8,
      title: "Tablou electric interior",
      description: "Instalare și conectare tablou electric",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_a4708a9b.jpg-2ierhCa42pLKC9zinN6oFyIbkhp1Fu.jpeg",
    },
    {
      id: 9,
      title: "Lucrări la rețeaua electrică",
      description: "Intervenții cu utilaje specializate",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_28695d24.jpg-PkDV029LoElPTlvWrZI5yXgoepBQmJ.jpeg",
    },
    {
      id: 10,
      title: "Pregătire instalație electrică",
      description: "Montaj suport și tablou electric",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_2e5e49af.jpg-PQKvmDDNKjops13bzDljt9etTmjulL.jpeg",
    },
    {
      id: 11,
      title: "Contor electric încorporat",
      description: "Instalare contor în perete",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_5dd05476.jpg-x97HL4LHJHB9SVxApIQcvIpae4HYIj.jpeg",
    },
    {
      id: 12,
      title: "Materiale pentru instalații electrice",
      description: "Pregătire materiale pentru montaj",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.10_17698e8d.jpg-QcfOqDVYyXzq7jSTwvjv97MTuuNvSC.jpeg",
    },
  ]

  return (
    <div className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center mb-8">
          <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Înapoi la pagina principală
          </Link>
        </div>

        <h1 className="text-3xl font-bold text-blue-800 mb-8">Galerie proiecte</h1>
        <p className="text-gray-600 mb-8 max-w-3xl">
          Explorați o selecție din proiectele noastre recente. ElectroAlex oferă servicii complete de instalații
          electrice pentru clienți rezidențiali și comerciali, inclusiv instalarea contoarelor, iluminat stradal, și
          lucrări la rețelele electrice.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="relative h-64">
                <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-lg text-blue-700">{project.title}</h3>
                <p className="text-gray-600 mt-1">{project.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
