import { Clock, Award, CheckCircle } from "lucide-react"

export default function DespreNoiPage() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-blue-800 mb-8 text-center">Despre noi</h1>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-8">
              <h2 className="text-2xl font-semibold text-blue-700 mb-6">
                Experiență și profesionalism în instalații electrice
              </h2>

              <p className="text-gray-700 mb-4">
                ElectroAlex Arbore este o companie specializată în instalații și branșamente electrice, oferind servicii
                complete pentru clienți rezidențiali și comerciali din județul Suceava.
              </p>

              <p className="text-gray-700 mb-4">
                Cu o experiență vastă în domeniu, echipa noastră de electricieni calificați asigură lucrări de înaltă
                calitate, respectând toate normele și standardele în vigoare.
              </p>

              <p className="text-gray-700 mb-6">
                Pe lângă serviciile de instalații electrice, dispunem și de un magazin fizic în centrul comunei Arbore,
                unde puteți găsi o gamă variată de produse electrice și accesorii.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-10">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <div className="flex items-center mb-4">
                    <Clock className="h-10 w-10 text-blue-600 mr-4" />
                    <h3 className="text-xl font-semibold text-blue-700">Peste 30 de ani de experiență</h3>
                  </div>
                  <p className="text-gray-600">
                    Cu o activitate de peste trei decenii în domeniul instalațiilor electrice, am acumulat expertiza
                    necesară pentru a oferi soluții optime pentru orice tip de proiect.
                  </p>
                </div>

                <div className="bg-blue-50 p-6 rounded-lg">
                  <div className="flex items-center mb-4">
                    <Award className="h-10 w-10 text-blue-600 mr-4" />
                    <h3 className="text-xl font-semibold text-blue-700">Autorizați ANRE</h3>
                  </div>
                  <p className="text-gray-600">
                    Suntem autorizați de Autoritatea Națională de Reglementare în Domeniul Energiei, ceea ce garantează
                    calitatea și siguranța lucrărilor noastre.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-8">
              <h2 className="text-2xl font-semibold text-blue-700 mb-6">De ce să alegeți ElectroAlex?</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-start mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Calitate garantată</h3>
                      <p className="text-gray-600">
                        Toate lucrările noastre respectă cele mai înalte standarde de calitate și siguranță.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Echipă profesionistă</h3>
                      <p className="text-gray-600">
                        Electricienii noștri sunt calificați și au experiență vastă în domeniu.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Prețuri competitive</h3>
                      <p className="text-gray-600">Oferim servicii de calitate la prețuri corecte și transparente.</p>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-start mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Promptitudine</h3>
                      <p className="text-gray-600">
                        Respectăm termenele de execuție și suntem disponibili pentru urgențe.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Garanție pentru lucrări</h3>
                      <p className="text-gray-600">
                        Toate serviciile noastre beneficiază de garanție conform legislației în vigoare.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 mt-1" />
                    <div>
                      <h3 className="font-semibold text-lg text-blue-700">Consultanță gratuită</h3>
                      <p className="text-gray-600">
                        Oferim consultanță tehnică gratuită pentru proiectele dumneavoastră.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
