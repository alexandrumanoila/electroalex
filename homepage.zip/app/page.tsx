import Image from "next/image"
import Link from "next/link"
import { Phone, Mail, MapPin, Clock, Award, CheckCircle } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section with Logo */}
      <section className="bg-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center mb-8">
            <div className="bg-white p-6 rounded-full">
              <h1 className="text-4xl font-bold text-blue-800">ELECTROALEX</h1>
            </div>
          </div>
          <h2 className="text-2xl font-semibold mb-4">ELECTROALEX ARBORE SRL</h2>
          <p className="text-xl mb-6">Instalații electrice profesionale</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/galerie" className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-md">
              Vezi Galeria
            </Link>
            <Link
              href="/contact"
              className="bg-blue-700 hover:bg-blue-600 text-white px-6 py-3 rounded-md border border-white"
            >
              Contactează-ne
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-800 mb-8 text-center">Despre noi</h2>
            <div className="bg-blue-50 p-8 rounded-lg shadow-md">
              <h3 className="text-2xl font-semibold text-blue-700 mb-4">
                Experiență și profesionalism în instalații electrice
              </h3>
              <p className="text-gray-700 mb-4">
                ElectroAlex Arbore este o companie specializată în instalații și branșamente electrice, oferind servicii
                complete pentru clienți rezidențiali și comerciali din județul Suceava.
              </p>
              <p className="text-gray-700 mb-4">
                Cu o experiență vastă în domeniu, echipa noastră de electricieni calificați asigură lucrări de înaltă
                calitate, respectând toate normele și standardele în vigoare.
              </p>
              <p className="text-gray-700 mb-6">
                Pe lângă serviciile de instalații electrice, dispunem și de un magazin fizic în centrul comunei Arbore,
                unde puteți găsi o gamă variată de produse electrice și accesorii.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div className="flex items-start">
                  <Clock className="h-10 w-10 text-blue-600 mr-4 flex-shrink-0" />
                  <div>
                    <h4 className="text-lg font-semibold text-blue-700 mb-2">Peste 30 de ani de experiență</h4>
                    <p className="text-gray-600">
                      Oferim servicii de calitate bazate pe experiența acumulată de-a lungul anilor.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Award className="h-10 w-10 text-blue-600 mr-4 flex-shrink-0" />
                  <div>
                    <h4 className="text-lg font-semibold text-blue-700 mb-2">Autorizați ANRE</h4>
                    <p className="text-gray-600">
                      Suntem autorizați de Autoritatea Națională de Reglementare în Domeniul Energiei.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-blue-800 mb-12 text-center">Serviciile noastre</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_22251971.jpg-KW52zR9BoX6FsCT306SFhwyHGRvXV7.jpeg"
                  alt="Instalații electrice"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-blue-700 mb-3">Instalații electrice</h3>
                <p className="text-gray-600 mb-4">
                  Realizăm instalații electrice complete pentru locuințe, spații comerciale și industriale.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Instalații interioare</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Instalații exterioare</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Tablouri electrice</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_e7e7470b.jpg-xa5yij2MzZRJPL1haNO5jRXrCRTf5r.jpeg"
                  alt="Branșamente electrice"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-blue-700 mb-3">Branșamente electrice</h3>
                <p className="text-gray-600 mb-4">
                  Executăm branșamente electrice și racorduri la rețeaua de distribuție.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Montaj contoare</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Racorduri la rețea</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Avize și documentație</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-48 relative">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_719a9687.jpg-evAOsgJ8Mu84OTHOCyZKaLbajCM7oV.jpeg"
                  alt="Iluminat public"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-blue-700 mb-3">Iluminat public</h3>
                <p className="text-gray-600 mb-4">Instalăm și întreținem sisteme de iluminat public și stradal.</p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Corpuri LED moderne</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Stâlpi de iluminat</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-700">Mentenanță periodică</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-blue-800 mb-8 text-center">Galerie proiecte</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="relative h-48 rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.13_b7a139da.jpg-mQoicb6ew32kNXsA85dwDANuBJZKGS.jpeg"
                alt="Proiect 1"
                fill
                className="object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-48 rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_a4708a9b.jpg-2ierhCa42pLKC9zinN6oFyIbkhp1Fu.jpeg"
                alt="Proiect 2"
                fill
                className="object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-48 rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.11_28695d24.jpg-PkDV029LoElPTlvWrZI5yXgoepBQmJ.jpeg"
                alt="Proiect 3"
                fill
                className="object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
            <div className="relative h-48 rounded-lg overflow-hidden">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-07%20at%2016.04.12_ed697200.jpg-hZp6A8rP8a1E2DLnHKWY0yOFqF28Vq.jpeg"
                alt="Proiect 4"
                fill
                className="object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
          </div>
          <div className="text-center mt-8">
            <Link
              href="/galerie"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md inline-block"
            >
              Vezi toate proiectele
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-blue-800 mb-8 text-center">Contact</h2>
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-blue-700 mb-4">Informații de contact</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                    <div>
                      <p className="font-medium">Telefon:</p>
                      <p>0770 670 185 / 0744 506 331</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <Mail className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                    <div>
                      <p className="font-medium">Email:</p>
                      <p>electroalex@yahoo.com</p>
                      <p>manoilaalex1@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-blue-600 mr-3 mt-1" />
                    <div>
                      <p className="font-medium">Adresă:</p>
                      <p className="mb-2">Electroalex, DN2K, Arbore 727015, Județul Suceava</p>
                      <div className="flex space-x-3 mt-2">
                        <a
                          href="https://www.google.com/maps/search/?api=1&query=Electroalex+Arbore+Suceava"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                        >
                          Google Maps
                        </a>
                        <a
                          href="https://www.waze.com/ul?ll=47.7252%2C25.9244&navigate=yes"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                        >
                          Waze
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-blue-700 mb-4">Trimite-ne un mesaj</h3>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Nume
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Mesaj
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    ></textarea>
                  </div>
                  <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                    Trimite mesajul
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
